package com.journaldev.spring.service;

import com.journaldev.spring.model.User;

public interface LoginService 
{
public boolean isValidUser(User user);
}
