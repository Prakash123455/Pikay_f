package com.journaldev.spring.dao;

public class RegistrationDAOImpl implements RegistrationDAO
{
	
	public boolean isSaveData(String userName, String password, String rePassword) 
	{
		return true;
	}

}
