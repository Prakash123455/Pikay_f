package com.Example.EmployeeDetails;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class TestEmp {
	public static void main(String[] args) {
	
	Resource r=new ClassPathResource("EmployeeData1.xml");
	BeanFactory bf=new XmlBeanFactory(r);
	EmployeePersonalDetails empd=(EmployeePersonalDetails) bf.getBean("EPD");
	empd.Display1();
	}
}
