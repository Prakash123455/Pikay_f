package com.journaldev.spring.service;

import com.journaldev.spring.dao.RegistrationDAO;

public class RegistrationServiceImpl implements RegistrationService
{
	private RegistrationDAO registrationdao;
	@Override
	public boolean isSaveData(String userName, String password, String rePassword)
	{
		
		return registrationdao.isSaveData(userName, password, rePassword);
	}
	
}
