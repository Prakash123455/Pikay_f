package com.journaldev.spring.dao;

import com.journaldev.spring.model.User;

public interface LoginDAO {

	public boolean isValidUser(User user);

}
