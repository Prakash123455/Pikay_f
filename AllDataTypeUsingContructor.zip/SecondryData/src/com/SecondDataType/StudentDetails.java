package com.SecondDataType;

public class StudentDetails {
	private int Sid;
	private String SName;
	private Address Saddress;
	
	
	public int getSid() {
		return Sid;
	}

	public void setSid(int sid) {
		Sid = sid;
	}

	public String getSName() {
		return SName;
	}

	public void setSName(String sName) {
		SName = sName;
	}

	public Address getSaddress() {
		return Saddress;
	}

	public void setSaddress(Address saddress) {
		Saddress = saddress;
	}

	public void Display() {
		System.out.println("StudentName" + SName + " Student Id" + Sid +"Student Address"+Saddress);
	}

}
