package com.journaldev.spring.dao;

import java.util.ArrayList;
import java.util.List;

import com.journaldev.spring.model.Flight;
import com.journaldev.spring.model.User;
import com.journaldev.spring.model.UserRegistration;

public interface PersonDAO {

	
	public boolean isValidUser(User user);
	public boolean isSaveData(UserRegistration userregistraion);
	public List<Flight> getSourcelist();
}
