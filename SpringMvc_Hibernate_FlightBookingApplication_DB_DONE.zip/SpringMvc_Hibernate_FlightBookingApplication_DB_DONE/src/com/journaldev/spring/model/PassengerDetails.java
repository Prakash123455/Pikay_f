package com.journaldev.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PASSENGERDETAILS")
public class PassengerDetails 
{
	@Id
	@Column(name="P_ID")
	private int P_ID;
	private String P_Fname;
	private String P_Lname;
	private String P_Gender;
	private String P_MobileNo;
	private String P_Email;
	public int getP_ID() {
		return P_ID;
	}
	public void setP_ID(int p_ID) {
		P_ID = p_ID;
	}
	public String getP_Fname() {
		return P_Fname;
	}
	public void setP_Fname(String p_Fname) {
		P_Fname = p_Fname;
	}
	public String getP_Lname() {
		return P_Lname;
	}
	public void setP_Lname(String p_Lname) {
		P_Lname = p_Lname;
	}
	public String getP_Gender() {
		return P_Gender;
	}
	public void setP_Gender(String p_Gender) {
		P_Gender = p_Gender;
	}
	public String getP_MobileNo() {
		return P_MobileNo;
	}
	public void setP_MobileNo(String p_MobileNo) {
		P_MobileNo = p_MobileNo;
	}
	public String getP_Email() {
		return P_Email;
	}
	public void setP_Email(String p_Email) {
		P_Email = p_Email;
	}
	@Override
	public String toString() {
		return "PassengerDetails [P_ID=" + P_ID + ", P_Fname=" + P_Fname + ", P_Lname=" + P_Lname + ", P_Gender="
				+ P_Gender + ", P_MobileNo=" + P_MobileNo + ", P_Email=" + P_Email + "]";
	}
	
	
}
