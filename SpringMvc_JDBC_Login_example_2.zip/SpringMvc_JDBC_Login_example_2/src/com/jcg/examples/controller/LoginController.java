package com.jcg.examples.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.jcg.examples.delegate.LoginDelegate;
import com.jcg.examples.viewBean.LoginBean;
import com.jcg.examples.viewBean.RegisterBean;
import com.jcg.examples.viewBean.WelcomeBean;

@Controller
public class LoginController {
	@Autowired
	private LoginDelegate loginDelegate;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView DisplayHome(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView("home");
		return model;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView displayLogin(HttpServletRequest request, HttpServletResponse response, LoginBean loginBean) {
		ModelAndView model = new ModelAndView("login");
		// LoginBean loginBean = new LoginBean();
		model.addObject("loginBean", loginBean);
		return model;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView executeLogin(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("loginBean") LoginBean loginBean) {
		ModelAndView model = null;
		try {
			boolean isValidUser = loginDelegate.isValidUser(loginBean.getUsername(), loginBean.getPassword());
			boolean isValidUserFormat = loginDelegate.isValidUserFormat(loginBean.getUsername(),
					loginBean.getPassword());

			if (isValidUser && isValidUserFormat) {
				System.out.println("User Login Successful");
				request.setAttribute("loggedInUser", loginBean.getUsername());
				model = new ModelAndView("welcome");
			}
			if (isValidUser == false) {
				model = new ModelAndView("login");
				request.setAttribute("message", "Invalid credentials!!");
			}
			if (isValidUserFormat == false) {
				model = new ModelAndView("login");
				request.setAttribute("message1", "Username should contains only numbers!!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return model;
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public ModelAndView executeWelcome(HttpServletRequest request, HttpServletResponse response,
			WelcomeBean welcomeBean) {
		ModelAndView mv1 = new ModelAndView("welcome");
		mv1.addObject("welcomeBean", welcomeBean);
		return mv1;
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.POST)
	public ModelAndView executeWelcome1(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("welcomeBean") WelcomeBean welcomeBean) {
		ModelAndView mv1 = null;
		try {
			boolean isSaveDetails = loginDelegate.isSaveDetails(welcomeBean.getFirstName(), welcomeBean.getLastName(),
					welcomeBean.getAge());
			mv1 = new ModelAndView("welcomepost");
			request.setAttribute("FirstName", welcomeBean.getFirstName());
			request.setAttribute("LastName", welcomeBean.getLastName());
			request.setAttribute("Age", welcomeBean.getAge());
			mv1.addObject("welcomeBean");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv1;
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView executeRegister(HttpServletRequest request, HttpServletResponse response,
			RegisterBean registerBean) {
		ModelAndView mv2 = new ModelAndView("register");
		mv2.addObject("registerBean", registerBean);
		return mv2;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView executeRegister1(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("registerBean") RegisterBean registerBean) {
		ModelAndView mv2 = null;
		try {
			if (registerBean.getPassword().equals(registerBean.getRePassword())) {
				loginDelegate.registeration(registerBean.getUserName(), registerBean.getPassword(),
						registerBean.getRePassword());
				request.setAttribute("registerdUser", registerBean.getUserName());
				mv2 = new ModelAndView("registerConfirmation");
				mv2.addObject("registerBean", registerBean);
			}
			else
			{
				mv2 = new ModelAndView("register");
				request.setAttribute("message3", "Password didnot matched!!");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return mv2;
	}

}
