package com.journaldev.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.journaldev.spring.model.AvailableFlight;
import com.journaldev.spring.model.Flight;
import com.journaldev.spring.model.PassengerDetails;
import com.journaldev.spring.model.User;
import com.journaldev.spring.model.UserRegistration;

@Repository
public class PersonDAOImpl implements PersonDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(PersonDAOImpl.class);

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf)
	{
		this.sessionFactory = sf;
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean isValidUser(User user)
	{
		boolean usrvalidornot = false;
		Session session = this.sessionFactory.getCurrentSession();
		List<User> al = session.createQuery("from User").list();
		for (int i = 0; i <al.size(); i++) 
		{
			User dbuser=al.get(i);
			if(user.getUsername().equals(dbuser.getUsername())&& user.getPassword().equals(dbuser.getPassword()))
			{
				//System.out.println("BDUSER AND ENTERED USER ARE EQUAL");
				usrvalidornot= true;
				break;
			}
		}
		return usrvalidornot;
	}

	@Override
	public boolean isSaveData(UserRegistration userregistraion) {

		Session session = this.sessionFactory.getCurrentSession();
		session.persist(userregistraion);
		logger.info("User Saved, User details=" + userregistraion);
		return true;
	}
	@Override
	public List<Flight> getSourcelist()
	{
		Session session = this.sessionFactory.getCurrentSession();
		List<Flight> FlightDetails = session.createQuery("from Flight").list();
		//System.out.println("DAO IML-------"+FlightDetails);
		return  FlightDetails;
	}
	
	@Override
	public List<AvailableFlight> getAvailableFlightlist()
	{
		Session session = this.sessionFactory.getCurrentSession();
		List<AvailableFlight> AvailableFlightList = session.createQuery("from AvailableFlight").list();
		return  AvailableFlightList;
	}

	@Override
	public boolean isSavePassenger(PassengerDetails passengerdetails)
	{
		
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(passengerdetails);
		logger.info("Passenger details Saved, Passenger details=" + passengerdetails);
		return true;
	}
}
