package com.journaldev.spring.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "FLIGHT")
public class Flight {
	@Id
	@Column(name = "source")
	private String source;
	private String destination;
	private String typeOftrip;

	//@Temporal(TemporalType.DATE)
	//@DateTimeFormat(pattern = "dd.MM.yyyy")
	private String departuredate;

	//@Temporal(TemporalType.DATE)
	//@DateTimeFormat(pattern = "dd.MM.yyyy")
	private String arrivaldate;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDeparturedate() {
		return departuredate;
	}

	public void setDeparturedate(String departuredate) {
		this.departuredate = departuredate;
	}

	public String getArrivaldate() {
		return arrivaldate;
	}

	public void setArrivaldate(String arrivaldate) {
		this.arrivaldate = arrivaldate;
	}

	public String getTypeOftrip() {
		return typeOftrip;
	}

	public void setTypeOftrip(String typeOftrip) {
		this.typeOftrip = typeOftrip;
	}

	@Override
	public String toString() {
		return "Flight [source=" + source + ", destination=" + destination + ", departuredate=" + departuredate
				+ ", arrivaldate=" + arrivaldate + ", typeOftrip=" + typeOftrip + "]";
	}

}
