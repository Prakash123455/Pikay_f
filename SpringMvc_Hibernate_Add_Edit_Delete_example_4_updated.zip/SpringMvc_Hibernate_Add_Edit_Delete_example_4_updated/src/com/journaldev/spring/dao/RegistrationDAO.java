package com.journaldev.spring.dao;

public interface RegistrationDAO 
{
	public boolean isSaveData(String userName, String password, String rePassword); 
	
}
