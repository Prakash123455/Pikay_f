package com.jcg.examples.delegate;

import java.sql.SQLException;

import com.jcg.examples.service.UserService;

public class LoginDelegate
{
		private UserService userService;

		public UserService getUserService()
		{
				return this.userService;
		}

		public void setUserService(UserService userService)
		{
				this.userService = userService;
		}

		public boolean isValidUser(String username, String password) throws SQLException
    {
		    return userService.isValidUser(username, password);
    }
		
		public boolean isValidUserFormat(String username, String password) throws SQLException
	    {
			    return userService.isValidUserFormat(username, password);
	    }
		public boolean isSaveDetails(String FirstName,String LastName,String Age)throws SQLException
		{
			return userService.isSaveDeatails(FirstName,LastName, Age);
		}

		public void registeration(String userName, String password, String rePassword) throws SQLException
		{
			userService.isSaveRegistrationDeatails(userName,password, rePassword);			
		}
}
