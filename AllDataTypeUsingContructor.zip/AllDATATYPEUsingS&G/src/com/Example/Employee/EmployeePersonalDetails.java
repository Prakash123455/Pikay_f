package com.Example.Employee;

import java.util.List;
import java.util.Map;

public class EmployeePersonalDetails {
	private int EmpID;
	private String EmpName;
	private String EmpAddress;
	private EmployeeSalaryDetails Empesd;

	private List Emplist;
	private Map Empmap;

	public int getEmpID() {
		return EmpID;
	}

	public void setEmpID(int empID) {
		EmpID = empID;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public String getEmpAddress() {
		return EmpAddress;
	}

	public void setEmpAddress(String empAddress) {
		EmpAddress = empAddress;
	}

	public EmployeeSalaryDetails getEmpesd() {
		return Empesd;
	}

	public void setEmpesd(EmployeeSalaryDetails empesd) {
		Empesd = empesd;
	}

	public List getEmplist() {
		return Emplist;
	}

	public void setEmplist(List emplist) {
		Emplist = emplist;
	}

	public Map getEmpmap() {
		return Empmap;
	}

	public void setEmpmap(Map empmap) {
		Empmap = empmap;
	}

	@Override
	public String toString() {
		return "EmpID=" + EmpID + ", EmpName=" + EmpName + ", EmpAddress=" + EmpAddress
				+ ", Empesd=" + Empesd + ", Emplist=" + Emplist + ", Empmap=" + Empmap;
	}
	
	public void Display()
	{
		System.out.println("EmpID=" + EmpID + ", EmpName=" + EmpName + ", EmpAddress=" + EmpAddress+ ", Empesd=" + Empesd + ", Emplist=" + Emplist + ", Empmap=" + Empmap);
	}
}
