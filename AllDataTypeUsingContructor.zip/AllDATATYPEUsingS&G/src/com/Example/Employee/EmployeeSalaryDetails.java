package com.Example.Employee;

public class EmployeeSalaryDetails {
private int GrossSalary;
private int BaseSalary;
private int VariableSalary;
public int getGrossSalary() {
	return GrossSalary;
}
@Override
public String toString() {
	return "GrossSalary=" + GrossSalary + ", BaseSalary=" + BaseSalary + ", VariableSalary="
			+ VariableSalary;
}
public void setGrossSalary(int grossSalary) {
	GrossSalary = grossSalary;
}
public int getBaseSalary() {
	return BaseSalary;
}
public void setBaseSalary(int baseSalary) {
	BaseSalary = baseSalary;
}
public int getVariableSalary() {
	return VariableSalary;
}
public void setVariableSalary(int variableSalary) {
	VariableSalary = variableSalary;
}
}
