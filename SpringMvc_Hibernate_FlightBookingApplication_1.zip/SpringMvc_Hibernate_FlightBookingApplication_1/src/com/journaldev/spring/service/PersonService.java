package com.journaldev.spring.service;

import java.util.List;

import com.journaldev.spring.model.User;

public interface PersonService {
	
	
	public boolean isValidUser(User user);
	public boolean isSaveData(String userName, String password, String rePassword);

	
	
}
