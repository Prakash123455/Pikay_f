package com.journaldev.spring.dao;

import java.util.List;

import com.journaldev.spring.model.User;

public interface PersonDAO {

	
	public boolean isValidUser(User user);
	public boolean isSaveData(String userName, String password, String rePassword);
}
