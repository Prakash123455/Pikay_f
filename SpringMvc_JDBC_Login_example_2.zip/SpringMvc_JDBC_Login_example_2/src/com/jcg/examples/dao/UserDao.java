package com.jcg.examples.dao;

import java.sql.SQLException;

/**
 * @author CENTAUR
 * This interface will be used to communicate with the
 * Database
 */
public interface UserDao
{
		public boolean isValidUser(String username, String password) throws SQLException;
		public boolean isValidUserFormat(String username, String password) throws SQLException;
		public boolean isSaveDeatails(String FirstName, String LastName, String Age) throws SQLException;
		public void isSaveRegistrationDeatails(String userName, String password, String rePassword)  throws SQLException;
		}
