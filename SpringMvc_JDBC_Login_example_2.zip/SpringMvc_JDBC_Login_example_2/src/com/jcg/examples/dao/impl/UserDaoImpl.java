package com.jcg.examples.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;

import org.springframework.web.servlet.ModelAndView;

import com.jcg.examples.dao.UserDao;

/**
 * @author CENTAUR
 */
public class UserDaoImpl implements UserDao {

	DataSource dataSource;

	public DataSource getDataSource() {
		return this.dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public boolean isValidUser(String username, String password) throws SQLException {
		String query = "Select count(1) from user where username = ? and password = ?";
		PreparedStatement pstmt = dataSource.getConnection().prepareStatement(query);
		pstmt.setString(1, username);
		pstmt.setString(2, password);
		ResultSet resultSet = pstmt.executeQuery();
		if (resultSet.next())
			return (resultSet.getInt(1) > 0);
		else
			return false;
	}

	@Override
	public boolean isValidUserFormat(String username, String password) throws SQLException {

		if (username.matches("[0-9]*")) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean isSaveDeatails(String FirstName, String LastName, String Age) throws SQLException {
		String query = "INSERT INTO userdetails(FirstName,LastName,Age) VALUES(?,?,?)";
		PreparedStatement pstmt = dataSource.getConnection().prepareStatement(query);
		pstmt.setString(1, FirstName);
		pstmt.setString(2, LastName);
		pstmt.setString(3, Age);
		pstmt.executeUpdate();
		return true;
	}

	@Override
	public void isSaveRegistrationDeatails(String userName, String password, String rePassword) throws SQLException {
		String query = "INSERT INTO user(username,password) VALUES(?,?)";
		PreparedStatement pstmt = dataSource.getConnection().prepareStatement(query);
		pstmt.setString(1, userName);
		pstmt.setString(2, password);
		pstmt.executeUpdate();
				
	}

}