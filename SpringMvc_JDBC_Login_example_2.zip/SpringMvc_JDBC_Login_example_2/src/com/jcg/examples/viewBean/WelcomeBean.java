package com.jcg.examples.viewBean;

public class WelcomeBean {
private String FirstName;
private String LastName;
private String Age;
public String getFirstName() {
	return FirstName;
}
public void setFirstName(String firstName) {
	FirstName = firstName;
}
public String getLastName() {
	return LastName;
}
public void setLastName(String lastName) {
	LastName = lastName;
}
public String getAge() {
	return Age;
}
public void setAge(String age) {
	Age = age;
}

}
