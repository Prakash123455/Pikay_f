package com.mvc.example;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.portlet.ModelAndView;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

@Controller
public class HelloController 
{
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String executeHome(HttpServletRequest request, HttpServletResponse response)
	{
		System.out.println("Entered Home ");
		ModelAndView mv= new ModelAndView("home");
		return "home";
	}
	

}
