package com.journaldev.spring.service;

import org.springframework.stereotype.Service;

import com.journaldev.spring.dao.LoginDAO;
import com.journaldev.spring.model.User;


@Service
public class LoginServiceImpl implements LoginService 
{
	private LoginDAO logindao;
	
	public boolean isValidUser(User user)
	{
		return logindao.isValidUser(user);
	}
	

}
