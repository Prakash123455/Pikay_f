package com.journaldev.spring.service;

public interface RegistrationService 
{

	public boolean isSaveData(String userName, String password, String rePassword);

}
