package com.test;

public class Address {
	
		private String Saddress;
		private String Sdistrict;
		private String Scountry;
		public Address(String saddress, String sdistrict, String scountry) {
			super();
			Saddress = saddress;
			Sdistrict = sdistrict;
			Scountry = scountry;
		}
		@Override
		public String toString() {
			return " Studentaddress=" + Saddress + ", Studentdistrict=" + Sdistrict + ", Studentcountry=" + Scountry ;
		}
		
		

	}

