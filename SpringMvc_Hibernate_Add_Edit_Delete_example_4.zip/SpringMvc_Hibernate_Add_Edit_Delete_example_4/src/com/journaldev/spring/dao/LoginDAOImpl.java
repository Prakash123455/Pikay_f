package com.journaldev.spring.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.journaldev.spring.model.Person;
import com.journaldev.spring.model.User;

@Repository
public class LoginDAOImpl implements LoginDAO {

	private static final Logger logger = LoggerFactory.getLogger(PersonDAOImpl.class);

	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public boolean isValidUser(User user) {

		Session session = this.sessionFactory.getCurrentSession();
		session.persist(user);

		logger.info("Person saved successfully, Person Details=" + user);

		return true;
	}

}
