package com.journaldev.spring;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.journaldev.spring.model.Flight;
import com.journaldev.spring.model.User;
import com.journaldev.spring.model.UserRegistration;
import com.journaldev.spring.service.PersonService;

@Controller
public class PersonController {

	private PersonService personService;

	@Autowired(required = true)
	@Qualifier(value = "personService")
	public void setPersonService(PersonService ps) {
		this.personService = ps;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView Home(HttpServletRequest req, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest req, HttpServletResponse res, User user) {
		ModelAndView mv = new ModelAndView("login");
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginPost(HttpServletRequest req, HttpServletResponse res, @ModelAttribute("user") User user,
			@ModelAttribute("flight") Flight flight) {
		ModelAndView mv = null;
		// validate the user
		try {
			boolean isValidUser = personService.isValidUser(user);
			System.out.println("USER VALID OR NOT:-" + isValidUser);
			if (isValidUser) {
				System.out.println("User Login Successful");
				req.setAttribute("loggedInUser", user.getUsername());

				ArrayList al = new ArrayList();
				al.add("PUNE");
				al.add("BANGALORE");
				al.add("DELHI");

				ArrayList al1 = new ArrayList();
				al1.add("USA");
				al1.add("UK");
				al1.add("CHINA");

				mv = new ModelAndView("searchflight");
				mv.addObject("flight", flight);
				mv.addObject("sourcelist", al);
				mv.addObject("destinationlist", al1);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView Register(HttpServletRequest req, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView("register");
		return mv;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView Registerpost(HttpServletRequest req, HttpServletResponse res,
			@ModelAttribute("userregistraion") UserRegistration userregistraion) {
		ModelAndView mv = null;
		// validate the user Registration
		try {
			boolean isSaveData = personService.isSaveData(userregistraion.getUserName(), userregistraion.getPassword(),
					userregistraion.getRePassword());
			System.out.println("DATA IS SAVED OR NOT:-" + isSaveData);
			if (isSaveData) {
				mv = new ModelAndView("register");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}

	@RequestMapping(value = "/flight", method = RequestMethod.POST)
	public ModelAndView addFlight(@ModelAttribute("flight") Flight flight) 
	{
		ModelAndView mv = new ModelAndView("test");
		return mv;

	}

}
